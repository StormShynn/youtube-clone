# Mini-YouTube-App
About Mini YouTube App --> user can search any video --> user will get 15 videos --> user can play the video as well  --> HTML | CSS | JAVASCRIPT
